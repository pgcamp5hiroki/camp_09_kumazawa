<?php
session_start();

// ログイン状態チェック
if (!isset($_SESSION["NAME"])) {
    header("Location: Logout.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="main.css">
</head>
<body>
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script src="main.js"></script>
<header>
<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT2LKIuSCtqVHovzIx0bQeRnFKyAw90o_1UZ4jygwP_ixzrEiE2rw" alt="">
<a href="Login.php">ログイン</a>
<a href="asobi.php">遊び</a>
<a href="Logout.php">ログアウト</a>
<p>ようこそ<?php echo htmlspecialchars($_SESSION["NAME"], ENT_QUOTES); ?>さん</p>  <!-- ユーザー名をechoで表示 -->
</header>
<h1>風景写真スライドショー</h1>
<div id="slide">
<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQuzNasDQfQ4B-050zm0IxHMsCd9HOpDRwd1_tnSRhJ9lj7X3PBqA">
<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQDr983Ng67T9Vt6guSA4MbN1pKXdfmkkQmmAmWbbKbUDSor17dYQ">
<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR1XqyksaAfD9rc_WC24puRpasS3PThtVQjOrEdNXR42zSishuJcA">
</div>
<div class="nav">
<p id="nav-r"><a href="#">次へ</a></p>
<p id="nav-l"><a href="#">戻る</a></p>
</div>
<footer>
<p><a href="login.php">Topへもどる</a></p>
</footer>

    </body>
</html>
