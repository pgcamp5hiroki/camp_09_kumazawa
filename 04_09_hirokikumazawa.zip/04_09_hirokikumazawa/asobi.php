<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="asobi.css">
</head>
<body>

<div id="true_area">
    <div class="head">賛成</div>
</div>
<div id="false_area">
    <div class="head">反対</div>
</div>

<div class="btn_area">
    <div id="true_btn" class="btn">賛成に1票</div>
    <div id="false_btn" class="btn">反対に1票</div>
</div>
<div class="osuna">絶対に押すな！！</div>
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script src="asobi.js"></script>    
</body>
</html>